"""Re-fetch the selected questions and accepted answers from the Stack Exchange API."""
import csv
import json
import time
from pathlib import Path
import requests

ROOT = Path(__file__).resolve().parent

def download(method, ids):
    items = []
    for offset in range(0, len(ids), 80):
        batch = ";".join(ids[offset:offset + 80])
        response = requests.get(f"https://api.stackexchange.com/2.3/{method}/{batch}",
                                params={"site": "stackoverflow", "pagesize": 100, "filter": "withbody"},
                                timeout=40)
        response.raise_for_status()
        result = response.json()
        items.extend(result["items"])
        if result.get("backoff"):
            time.sleep(result["backoff"] + 1)
    return items

def main():
    with (ROOT / "review_round7.csv").open(encoding="utf-8", newline="") as file:
        rows = list(csv.DictReader(file))
    questions = download("questions", [row["issue_number"] for row in rows])
    answers = download("answers", [row["endpoint_url"].rsplit("/", 1)[1] for row in rows])
    output = ROOT / "stack_overflow_live.json"
    output.write_text(json.dumps({"questions": questions, "answers": answers}, ensure_ascii=False),
                      encoding="utf-8")
    print(f"Retrieved {len(questions)} questions and {len(answers)} answers. Expected 250 of each.")

if __name__ == "__main__":
    main()
