# DevBugger data pipeline

With the project virtual environment active, extract this ZIP and run the following command from the extracted folder.

    python build_dataset_800.py

The build uses pandas and NumPy. It recreates the 550 GitHub rows from the six supplied review rounds and GitHub overrides, then appends the 250 reviewed Stack Overflow questions from round 7. The output is devbugger_dataset_800.csv. Rebuilding from the frozen CSVs works offline.

The github folder contains the original Python files and review inputs. The stackoverflow folder contains review_round7.csv with the same review-table headers, six label overrides and source_metadata.csv with attribution and row IDs. The accepted-answer creation time supplies the resolution endpoint. Repository, author association and reaction count are blank on Stack Overflow rows.

To retrieve current public question and answer records for the archived IDs, run python stackoverflow/fetch_stackoverflow.py with requests installed. This optional fetch writes a separate JSON file. Online posts can change or be deleted.
