"""Rebuild the 800-row CSV from the frozen review files. Run with Python."""
import csv
import subprocess
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
GITHUB = ROOT / "github"
SO = ROOT / "stackoverflow"

def read(path):
    with path.open(encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        return reader.fieldnames, list(reader)

def main():
    quotas = "CORS_Error=35,Authentication=35,API_Error=35,State_Management=35,Database_Connection=35"
    subprocess.run([sys.executable, str(GITHUB / "build_dataset.py"), "final", "--cap", "35",
                    "--base-rounds", "4", "--add", quotas], check=True)
    fields, rows = read(GITHUB / "devbugger_dataset.csv")
    _, reviews = read(SO / "review_round7.csv")
    _, metadata = read(SO / "source_metadata.csv")
    _, overrides = read(SO / "label_overrides.csv")
    source = {row["url"]: row for row in metadata}
    labels = {row["url"]: row["Bug_Type"] for row in overrides}
    if {r["url"] for r in reviews} != set(source) or not set(labels) <= set(source):
        raise ValueError("Review and provenance URLs do not match")
    for review in reviews:
        url = review["url"]
        candidate = review["candidate_Bug_Type"]
        row = {field: review.get(field, "") for field in fields}
        row.update(source[url])
        row.update(Bug_Type=labels.get(url, candidate), review_status="codex_reviewed", review_round="7",
                   label_source="relabelled_in_review" if url in labels else "rule_confirmed_by_review")
        rows.append(row)
    if Counter(r["source"] for r in rows) != {"GitHub": 550, "Stack Overflow": 250}:
        raise ValueError("Unexpected source counts")
    if len({r["url"] for r in rows}) != 800 or len({r["row_id"] for r in rows}) != 800:
        raise ValueError("Duplicate report or row ID")
    output = ROOT / "devbugger_dataset_800.csv"
    staging = output.with_suffix(".tmp")
    with staging.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    staging.replace(output)
    print(f"Wrote {len(rows)} reports to {output}")

if __name__ == "__main__":
    main()
