#!/usr/bin/env python3
"""
DevBugger - step 1: collect closed GitHub issues for the 5 bug classes.

Why the Search API?
  One request returns up to 100 issues *with* body text, timestamps, comment
  counts and labels, so we don't need one request per issue.
Rate limit:
  10 requests/min without a token, 30/min with one:  export GITHUB_TOKEN=ghp_...
Caching:
  Every response is saved in ./cache, so re-running costs nothing.
Pulling in rows from an earlier candidates file:
  python fetch_github_issues.py --recover devbugger_candidates.csv
  (looks each missing GitHub row up by title, keeps the hit whose URL matches)

Output: raw_issues.json  (one entry per unique issue, with the class "hints"
of the queries that found it - hints are only a starting point, not labels).
"""
import hashlib
import json
import os
import sys
import time

import requests

URL = "https://api.github.com/search/issues"
TOKEN = os.environ.get("GITHUB_TOKEN")
HEADERS = {
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "User-Agent": "devbugger-dataset-builder",
}
if TOKEN:
    HEADERS["Authorization"] = f"Bearer {TOKEN}"
PAUSE = 2.5 if TOKEN else 6.5          # seconds between *uncached* requests

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(HERE, "cache")
os.makedirs(CACHE, exist_ok=True)

# (class hint, repo, search terms, max pages of 100)
# Keep each query to <= 5 terms: GitHub allows at most 5 AND/OR/NOT operators.
PLAN = [
    # ---- State_Management (React-side state bugs) ----
    ("State_Management", "reduxjs/redux", 'state OR reducer OR store OR rerender OR stale', 2),
    ("State_Management", "reduxjs/redux-toolkit", 'state OR selector OR stale OR rerender OR reducer', 2),
    ("State_Management", "reduxjs/react-redux", 'useSelector OR connect OR rerender OR stale OR state', 2),
    ("State_Management", "pmndrs/zustand", 'state OR rerender OR stale OR store OR persist', 2),
    ("State_Management", "TanStack/query", 'state OR stale OR rerender OR cache OR useState', 2),
    ("State_Management", "facebook/react", 'useState OR useReducer OR "stale state" OR rerender OR "state not updating"', 2),
    ("State_Management", "facebook/react", 'useContext OR "context provider" OR "infinite loop" OR "too many re-renders" OR useEffect', 1),
    ("State_Management", "mobxjs/mobx", 'observer OR rerender OR state OR observable', 1),
    ("State_Management", "pmndrs/jotai", 'state OR rerender OR atom OR stale', 1),
    ("State_Management", "recoiljs/recoil", 'state OR rerender OR selector OR stale', 1),
    ("State_Management", "rt2zz/redux-persist", 'persist OR rehydrate OR state OR store', 1),
    ("State_Management", "reduxjs/redux-thunk", 'thunk OR dispatch OR state OR store', 1),
    # ---- CORS_Error ----
    ("CORS_Error", "expressjs/cors", 'CORS OR origin OR preflight OR "Access-Control-Allow-Origin" OR credentials', 2),
    ("CORS_Error", "axios/axios", 'CORS OR "Access-Control-Allow-Origin" OR preflight OR cross-origin OR "blocked by CORS"', 2),
    ("CORS_Error", "expressjs/express", 'CORS OR "Access-Control-Allow-Origin" OR preflight OR cross-origin', 1),
    ("CORS_Error", "socketio/socket.io", 'CORS OR "Access-Control-Allow-Origin" OR preflight OR cross-origin', 2),
    ("CORS_Error", "webpack/webpack-dev-server", 'CORS OR "Access-Control-Allow-Origin" OR cross-origin', 1),
    ("CORS_Error", "vitejs/vite", 'CORS OR "Access-Control-Allow-Origin" OR preflight', 1),
    ("CORS_Error", "facebook/create-react-app", 'CORS OR "Access-Control-Allow-Origin" OR preflight OR proxy', 1),
    ("CORS_Error", "chimurenga/http-proxy-middleware", 'CORS OR "Access-Control-Allow-Origin" OR preflight', 1),
    ("CORS_Error", "node-fetch/node-fetch", 'CORS OR "Access-Control" OR preflight', 1),
    # ---- Authentication ----
    ("Authentication", "auth0/node-jsonwebtoken", 'expired OR invalid OR malformed OR signature OR secret', 2),
    ("Authentication", "auth0/express-jwt", 'token OR unauthorized OR jwt OR secret OR expired', 1),
    ("Authentication", "jaredhanson/passport", 'session OR login OR authenticate OR serializeUser OR logout', 2),
    ("Authentication", "mikenicholson/passport-jwt", 'token OR jwt OR unauthorized OR secret', 1),
    ("Authentication", "jaredhanson/passport-local", 'login OR authenticate OR session OR username', 1),
    ("Authentication", "expressjs/session", 'session OR cookie OR "req.session" OR store OR secure', 1),
    ("Authentication", "auth0/node-jwks-rsa", 'jwks OR token OR "signing key" OR expired', 1),
    ("Authentication", "nextauthjs/next-auth", 'session OR token OR login OR "sign in" OR credentials', 2),
    ("Authentication", "kelektiv/node.bcrypt.js", 'compare OR hash OR password', 1),
    # ---- API_Error ----
    ("API_Error", "axios/axios", '"Network Error" OR "status code" OR timeout OR interceptor OR "Request failed"', 2),
    ("API_Error", "axios/axios", 'headers OR "Content-Type" OR FormData OR params OR "response data"', 1),
    ("API_Error", "expressjs/express", '"req.body" OR "Cannot POST" OR "Cannot GET" OR "status code" OR "res.send"', 2),
    ("API_Error", "expressjs/body-parser", 'body OR "req.body" OR parse OR "payload too large" OR JSON', 1),
    ("API_Error", "expressjs/multer", 'upload OR multipart OR "req.file" OR boundary OR "Unexpected field"', 1),
    ("API_Error", "node-fetch/node-fetch", 'fetch OR response OR ECONNRESET OR timeout OR "Content-Type"', 1),
    ("API_Error", "sindresorhus/got", 'request OR response OR timeout OR ECONNRESET OR retry', 1),
    ("API_Error", "apollographql/apollo-client", '"network error" OR "400" OR fetch OR "status code" OR "Failed to fetch"', 1),
    ("API_Error", "nodejs/node", 'ECONNRESET OR "socket hang up" OR "http request" OR ERR_HTTP OR "status code"', 1),
    # ---- Database_Connection (MongoDB connectivity) ----
    ("Database_Connection", "Automattic/mongoose", 'MongooseServerSelectionError OR ECONNREFUSED OR "buffering timed out" OR "failed to connect" OR "connection timed out"', 3),
    ("Database_Connection", "Automattic/mongoose", 'Atlas OR "replica set" OR ENOTFOUND OR querySrv OR "authentication failed"', 2),
    ("Database_Connection", "Automattic/mongoose", 'disconnected OR reconnect OR "connection pool" OR "topology was destroyed" OR "connection closed"', 2),
    ("Database_Connection", "nodkz/mongodb-memory-server", 'connect OR ECONNREFUSED OR timeout OR connection', 1),
    ("Database_Connection", "parse-community/parse-server", 'MongoNetworkError OR MongoServerSelectionError OR ECONNREFUSED OR "connection"', 1),
    ("Database_Connection", "typegoose/typegoose", 'connect OR connection OR timeout', 1),
    ("Database_Connection", "vercel/next.js", 'MongoServerSelectionError OR MongoNetworkError OR "mongoose.connect" OR "MongoDB connection"', 1),
    ("Database_Connection", "agenda/agenda", 'mongo OR connection OR MongoNetworkError', 1),
    ("Database_Connection", "mongodb/node-mongodb-native", 'MongoServerSelectionError OR ECONNREFUSED OR connection OR timeout', 1),
    # extra repos so the class is not mongoose-only (added after a first review showed it was thin)
    ("Database_Connection", "RocketChat/Rocket.Chat", 'MongoServerSelectionError OR MongoNetworkError OR "MongoDB connection" OR "connect to MongoDB" OR ECONNREFUSED', 1),
    ("Database_Connection", "mongodb-js/compass", 'MongoServerSelectionError OR MongoNetworkError OR "failed to connect" OR ECONNREFUSED OR "connection timed out"', 1),
    ("Database_Connection", "mongodb-js/mongosh", 'MongoServerSelectionError OR MongoNetworkError OR "failed to connect" OR ECONNREFUSED OR "connection timed out"', 1),
    ("Database_Connection", "meteor/meteor", 'MongoServerSelectionError OR MongoNetworkError OR "MongoDB connection" OR "connect to MongoDB" OR ECONNREFUSED', 1),
    ("Database_Connection", "strapi/strapi", 'MongoServerSelectionError OR MongoNetworkError OR "MongoDB connection" OR "connect to MongoDB" OR ECONNREFUSED', 1),
    ("Database_Connection", "payloadcms/payload", 'MongoServerSelectionError OR MongoNetworkError OR "MongoDB connection" OR "connect to MongoDB" OR ECONNREFUSED', 1),
    ("Database_Connection", "prisma/prisma", 'MongoServerSelectionError OR "MongoDB connection" OR "connect to MongoDB" OR "mongodb+srv" OR "replica set"', 1),
    # ---- batch 2: +175 rows. New sources where one repo already fills its per-class cap ----
    # Database_Connection: more MongoDB-connectivity reports outside mongoose
    ("Database_Connection", "meanjs/mean", 'MongoError OR "failed to connect" OR ECONNREFUSED OR "connection refused" OR "MongoDB connection"', 2),
    ("Database_Connection", "linnovate/mean", 'MongoError OR "failed to connect" OR ECONNREFUSED OR "connection refused" OR "MongoDB connection"', 1),
    ("Database_Connection", "mongo-express/mongo-express", 'MongoError OR "failed to connect" OR ECONNREFUSED OR "connection refused" OR "MongoDB connection"', 2),
    ("Database_Connection", "nestjs/mongoose", 'MongooseServerSelectionError OR ECONNREFUSED OR "failed to connect" OR "connection timed out" OR "buffering timed out"', 1),
    ("Database_Connection", "typegoose/mongodb-memory-server", 'connect OR ECONNREFUSED OR timeout OR connection OR "failed to connect"', 1),
    ("Database_Connection", "keystonejs/keystone-classic", 'MongoError OR "failed to connect" OR ECONNREFUSED OR "connection refused" OR "MongoDB connection"', 1),
    ("Database_Connection", "loopbackio/loopback-connector-mongodb", 'MongoError OR "failed to connect" OR ECONNREFUSED OR "connection refused" OR "MongoDB connection"', 1),
    ("Database_Connection", "balderdashy/sails-mongo", 'MongoError OR "failed to connect" OR ECONNREFUSED OR "connection refused" OR "MongoDB connection"', 1),
    ("Database_Connection", "typeorm/typeorm", 'MongoError OR MongoNetworkError OR "mongodb connection" OR "topology was destroyed" OR MongoServerSelectionError', 1),
    ("Database_Connection", "RocketChat/Rocket.Chat", 'MongoServerSelectionError OR MongoNetworkError OR "MongoDB connection" OR "connect to MongoDB" OR ECONNREFUSED', 3),
    ("Database_Connection", "meteor/meteor", 'MongoServerSelectionError OR MongoNetworkError OR "MongoDB connection" OR "connect to MongoDB" OR ECONNREFUSED', 3),
    ("Database_Connection", "parse-community/parse-server", 'MongoNetworkError OR MongoServerSelectionError OR ECONNREFUSED OR "connection"', 3),
    # API_Error: HTTP clients/servers other than axios
    ("API_Error", "request/request", '"socket hang up" OR ECONNRESET OR ETIMEDOUT OR "status code" OR "Error: connect"', 2),
    ("API_Error", "ladjs/superagent", 'ECONNRESET OR "status code" OR timeout OR "Bad Request" OR "network"', 1),
    ("API_Error", "typicode/json-server", '404 OR 500 OR "Cannot GET" OR "status code" OR "Cannot POST"', 1),
    ("API_Error", "expressjs/express", '"Cannot set headers" OR "Unexpected token" OR "413" OR "404" OR "res.status"', 2),
    ("API_Error", "nodejs/undici", '"fetch failed" OR ECONNRESET OR UND_ERR OR "status code" OR timeout', 2),
    ("API_Error", "http-party/node-http-proxy", 'ECONNRESET OR "socket hang up" OR ECONNREFUSED OR timeout OR proxy', 1),
    ("API_Error", "sindresorhus/ky", 'fetch OR response OR timeout OR "status code" OR HTTPError', 1),
    ("API_Error", "node-fetch/node-fetch", 'ECONNRESET OR "socket hang up" OR "invalid json" OR "status" OR "body used already"', 1),
    ("API_Error", "apollographql/apollo-client", '"network error" OR "400" OR fetch OR "status code" OR "Failed to fetch"', 3),
    # CORS_Error: more frameworks and servers
    ("CORS_Error", "vercel/next.js", 'CORS OR "Access-Control-Allow-Origin" OR preflight OR cross-origin', 2),
    ("CORS_Error", "nestjs/nest", 'CORS OR "Access-Control-Allow-Origin" OR preflight OR cross-origin', 1),
    ("CORS_Error", "apollographql/apollo-server", 'CORS OR "Access-Control-Allow-Origin" OR preflight OR cross-origin', 1),
    ("CORS_Error", "socketio/engine.io", 'CORS OR "Access-Control-Allow-Origin" OR preflight OR cross-origin', 1),
    ("CORS_Error", "socketio/socket.io-client", 'CORS OR "Access-Control-Allow-Origin" OR preflight OR cross-origin', 1),
    ("CORS_Error", "strapi/strapi", 'CORS OR "Access-Control-Allow-Origin" OR preflight OR cross-origin', 1),
    ("CORS_Error", "parse-community/parse-server", 'CORS OR "Access-Control-Allow-Origin" OR preflight OR cross-origin', 1),
    ("CORS_Error", "directus/directus", 'CORS OR "Access-Control-Allow-Origin" OR preflight OR cross-origin', 1),
    ("CORS_Error", "feathersjs/feathers", 'CORS OR "Access-Control-Allow-Origin" OR preflight OR cross-origin', 1),
    ("CORS_Error", "http-party/node-http-proxy", 'CORS OR "Access-Control-Allow-Origin" OR preflight OR cross-origin', 1),
    ("CORS_Error", "auth0/auth0-spa-js", 'CORS OR "Access-Control-Allow-Origin" OR preflight OR cross-origin', 1),
    ("CORS_Error", "vitejs/vite", 'CORS OR "Access-Control-Allow-Origin" OR preflight', 2),
    # Authentication: more login/session libraries
    ("Authentication", "saintedlama/passport-local-mongoose", 'login OR authenticate OR password OR session OR salt', 1),
    ("Authentication", "expressjs/cookie-session", 'session OR cookie OR "req.session" OR login OR expired', 1),
    ("Authentication", "jaredhanson/passport-oauth2", 'oauth OR token OR callback OR state OR authorization', 1),
    ("Authentication", "jaredhanson/passport-google-oauth2", 'login OR oauth OR token OR callback OR "access token"', 1),
    ("Authentication", "firebase/firebase-js-sdk", 'signInWithEmailAndPassword OR onAuthStateChanged OR "auth/" OR "sign in" OR "id token"', 1),
    ("Authentication", "nextauthjs/next-auth", 'session OR token OR login OR "sign in" OR credentials', 3),
]


def log(msg):
    print(time.strftime("%H:%M:%S"), msg, flush=True)


def run_search(query, page):
    """Return (json, was_cached). None on permanent failure."""
    key = hashlib.md5(f"{query}|{page}".encode()).hexdigest()
    path = os.path.join(CACHE, key + ".json")
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f), True
    for _ in range(6):
        try:
            r = requests.get(URL, headers=HEADERS, params={"q": query, "per_page": 100, "page": page}, timeout=45)
        except requests.RequestException as e:
            log(f"network error: {e}; retrying in 15s")
            time.sleep(15)
            continue
        if r.status_code == 200:
            data = r.json()
            with open(path, "w") as f:
                json.dump(data, f)
            return data, False
        if r.status_code in (403, 429):
            wait = int(r.headers.get("Retry-After", 0)) or 65
            log(f"rate limited ({r.status_code}); sleeping {wait}s")
            time.sleep(wait)
            continue
        if r.status_code == 422:
            log(f"422 (bad query?) {r.text[:160]}")
            return None, False
        log(f"HTTP {r.status_code}: {r.text[:160]}")
        time.sleep(10)
    return None, False


def trim(it):
    """Keep only the fields we need."""
    u = it.get("user") or {}
    return {
        "html_url": it["html_url"],
        "number": it["number"],
        "repo": it["repository_url"].split("repos/")[1],
        "title": it["title"],
        "body": it.get("body") or "",
        "created_at": it["created_at"],
        "closed_at": it["closed_at"],
        "state_reason": it.get("state_reason"),
        "comments": it.get("comments", 0),
        "reactions": (it.get("reactions") or {}).get("total_count", 0),
        "labels": [l["name"] for l in it.get("labels", [])],
        "author_login": u.get("login"),
        "author_url": u.get("html_url"),
        "author_type": u.get("type"),
        "author_association": it.get("author_association"),
        "is_pr": "pull_request" in it,
    }


def recover(csv_path):
    """Look up GitHub rows of an earlier candidates CSV that raw_issues.json does not contain yet.

    Searches by title inside the row's repository and keeps the hit whose URL matches exactly,
    so rows you collected before are not lost when the collector is re-run.
    """
    import re
    import pandas as pd
    raw_path = os.path.join(HERE, "raw_issues.json")
    issues = {r["html_url"]: r for r in json.load(open(raw_path))}
    old = pd.read_csv(csv_path)
    todo = old[(old.source == "GitHub") & ~old.url.isin(issues)]
    log(f"{len(todo)} rows from {os.path.basename(csv_path)} are not collected yet; searching by title")
    found = 0
    for r in todo.itertuples():
        words = re.sub(r"[^A-Za-z0-9 ]+", " ", str(r.report_title)).split()
        hit = None
        for n in (8, 4):
            q = f"repo:{r.repository} is:issue in:title " + " ".join(words[:n])
            data, cached = run_search(q, 1)
            hit = next((it for it in (data or {}).get("items", []) if it["html_url"] == r.url), None)
            if not cached:
                time.sleep(PAUSE)
            if hit:
                break
        if hit:
            issues[r.url] = trim(hit) | {"hints": ["original_csv"]}
            found += 1
            with open(raw_path, "w") as fh:
                json.dump(list(issues.values()), fh)
        log(f"{'recovered' if hit else 'not found '} {r.url}")
    log(f"recovered {found} of {len(todo)}")


def main():
    issues = {}
    for i, (hint, repo, terms, pages) in enumerate(PLAN, 1):
        query = f"repo:{repo} is:issue is:closed reason:completed in:title,body {terms}"
        got = 0
        for page in range(1, pages + 1):
            data, cached = run_search(query, page)
            if not data or not data.get("items"):
                break
            for it in data["items"]:
                row = issues.setdefault(it["html_url"], trim(it) | {"hints": []})
                if hint not in row["hints"]:
                    row["hints"].append(hint)
            got += len(data["items"])
            if len(data["items"]) < 100:
                break
            if not cached:
                time.sleep(PAUSE)
        log(f"[{i}/{len(PLAN)}] {hint:<20} {repo:<34} +{got:<4} (unique so far: {len(issues)})")
        if not cached:
            time.sleep(PAUSE)
        with open(os.path.join(HERE, "raw_issues.json"), "w") as f:
            json.dump(list(issues.values()), f)
    log(f"done: {len(issues)} unique issues")


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "--recover":
        recover(sys.argv[2])          # python fetch_github_issues.py --recover devbugger_candidates.csv
    else:
        main()
