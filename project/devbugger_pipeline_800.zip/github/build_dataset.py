#!/usr/bin/env python3
"""
DevBugger - step 2: turn raw GitHub issues into a clean, labelled dataset.

    python build_dataset.py pool                       # raw_issues.json -> pool.csv
    python build_dataset.py sample --round 2 --counts Database_Connection=70,Authentication=25
                                                       # pool.csv -> review_round2.csv (rows to read and label)
    python build_dataset.py final --cap 35             # review_round*.csv + label_overrides.csv -> devbugger_dataset.csv
    python build_dataset.py final --cap 35 --base-rounds 4 --add CORS_Error=35,...   # keep rounds 1-4 exactly, add per-class quotas
    python build_dataset.py audit                      # leakage / quality checks on the finished dataset

Workflow:
  1. fetch_github_issues.py          -> raw_issues.json
  2. build_dataset.py pool           -> pool.csv (filtered, cleaned, features, keyword proposals)
  3. build_dataset.py sample ...     -> review_roundN.csv (rows to READ; round 1 is shipped frozen)
  4. read each row, write exceptions into label_overrides.csv (url, Bug_Type or DROP, note)
  5. build_dataset.py final --cap 35 --base-rounds 4 --add CORS_Error=35,Authentication=35,API_Error=35,State_Management=35,Database_Connection=35
                                     -> devbugger_dataset.csv  (rounds 1-4 = first 375 rows, kept exactly; rounds 5-6 add 175)
  6. build_dataset.py audit          -> leakage / quality checks

Design decisions (and why):
  * Bug reports only: no PRs, no bots, no feature requests, only issues closed as
    "completed" (so resolution_hours means "time until it was actually fixed").
  * De-duplicated on normalised title, so the same report can't land in both
    your train and test split.
  * Keyword rules only PROPOSE a label (candidate_Bug_Type). The final Bug_Type
    comes from reading each report and deciding on the ROOT CAUSE
    (label_overrides.csv records every change). If we trained on raw keyword
    labels, the model would just re-learn our keyword list.
  * Features are things known when the report is filed. comment_count,
    reaction_count and labels are only known afterwards - they are kept for
    analysis but flagged as leaky in devbugger_data_dictionary.csv.
"""
import argparse
import glob
import json
import math
import os
import re
import sys

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
P = lambda name: os.path.join(HERE, name)

CLASSES = ["CORS_Error", "API_Error", "State_Management", "Authentication", "Database_Connection"]

# --------------------------------------------------------------------------
# 1. Keyword rules  (pattern, weight).  Title hits count x3, body hits count x1.
# --------------------------------------------------------------------------
RULES = {
    "CORS_Error": [
        (r"\bcors\b", 3), (r"access-control-(?:allow|expose)-[a-z-]+", 3), (r"\bpreflight\b", 3),
        (r"cross[- ]origin", 2), (r"same[- ]origin", 2), (r"\bwithcredentials\b", 1),
    ],
    "Authentication": [
        (r"\bjwt\b|json ?web ?token|jsonwebtoken", 3),
        (r"tokenexpirederror|jsonwebtokenerror|invalid signature|(?:token|jwt)\W+(?:\w+\W+){0,3}(?:expired|invalid|malformed)", 3),
        (r"\bpassport\b", 2), (r"\b(?:log ?in|log ?out|sign ?in|sign ?out|signin|signout)\b", 2),
        (r"\bunauthori[sz]ed\b|\b401\b", 2), (r"\b(?:authenticat\w*|authoriz\w*)\b", 2),
        (r"\b(?:oauth\d?|refresh token|access token|bearer)\b", 2),
        (r"\bsession\b", 1), (r"\b(?:bcrypt|password)\b", 1), (r"\bcookie\b", 1), (r"\b403\b|forbidden", 1),
    ],
    "Database_Connection": [
        (r"mongooseserverselectionerror|mongoserverselectionerror|mongonetwork\w*error|mongoparseerror", 4),
        (r"mongoose\.(?:connect|createconnection)|mongoclient\.connect", 3),
        (r"econnrefused|enotfound|etimedout|querysrv", 2),
        (r"buffering timed out", 4),
        (r"\bconnect\w*\W+(?:\w+\W+){0,6}(?:timed? ?out|timeout|refused|closed|reset|lost|fail\w*)", 3),
        (r"\b(?:replica ?set|atlas|mongodb\+srv|mongodb://)", 2),
        (r"servers?electiontimeoutms|connecttimeoutms|sockettimeoutms|maxpoolsize|poolsize", 2),
        (r"topology (?:was )?destroyed", 3), (r"\b(?:reconnect\w*|disconnect\w*)\b", 2),
        (r"\b(?:mongo|mongodb|mongoose)\b", 1),
    ],
    "State_Management": [
        (r"\b(?:usestate|usereducer|usecontext|useselector|usedispatch|usestore)\b", 3),
        (r"\b(?:redux|zustand|mobx|recoil|jotai)\b", 2),
        (r"too many re-?renders|infinite (?:loop|render)", 3),
        (r"\bstale\b|state (?:is )?not updat\w+|not updating|(?:does(?: not|n'?t)|doesnt) update|not re-?render\w*|\bre-?render\w*", 3),
        (r"\b(?:persist\w*|rehydrat\w*)\b", 2),
        (r"\b(?:reducer|selector|dispatch|store|context)\b", 1), (r"\bstate\b", 1),
        (r"\buseeffect\b", 1), (r"\b(?:optimistic|cache|invalidat\w+|refetch)\b", 1),
    ],
    "API_Error": [
        (r"\b(?:axios|fetch|xhr|xmlhttprequest|http request|request failed|status code)\b", 2),
        (r"network ?error|err_network|econnreset|socket hang up|failed to fetch", 3),
        (r"cannot (?:get|post|put|delete)\b", 3),
        (r"\b(?:400|404|405|413|415|422|500|502|503|504)\b", 1),
        (r"bad request|not found|internal server error|payload too large", 2),
        (r"\b(?:req\.body|res\.(?:send|json|status)|body-?parser|multipart|form-?data|content-type|boundary)\b", 2),
        (r"unexpected token\W+(?:\w+\W+){0,4}json|json parse|invalid json", 2),
        (r"\b(?:interceptor|timeout|payload|endpoint|route|middleware|headers?)\b", 1),
    ],
}
COMPILED = {c: [(re.compile(p, re.I), w) for p, w in pats] for c, pats in RULES.items()}

# Strong, human-readable error phrases (first one found goes in matched_error_phrase)
PHRASES = [
    "Access-Control-Allow-Origin", "blocked by CORS policy", "MongooseServerSelectionError",
    "MongoServerSelectionError", "MongoNetworkError", "ECONNREFUSED", "buffering timed out",
    "jwt expired", "jwt malformed", "invalid signature", "TokenExpiredError", "JsonWebTokenError",
    "Network Error", "ERR_NETWORK", "ECONNRESET", "socket hang up", "Cannot POST", "Cannot GET",
    "Too many re-renders", "Request failed with status code", "Failed to fetch", "ENOTFOUND", "querySrv",
]


def propose_label(title, body_head):
    """Return (label, confidence, top_score, margin) from keyword evidence."""
    scores = {}
    for c, pats in COMPILED.items():
        t = sum(w for rx, w in pats if rx.search(title))
        b = sum(w for rx, w in pats if rx.search(body_head))
        scores[c] = 3 * t + min(b, 12)
    ranked = sorted(scores.items(), key=lambda kv: -kv[1])
    (c1, s1), (_, s2) = ranked[0], ranked[1]
    margin = s1 - s2
    if s1 >= 9 and margin >= 5:
        conf = "high"
    elif s1 >= 5 and margin >= 3:
        conf = "medium"
    else:
        conf = "low"
    return c1, conf, s1, margin


# --------------------------------------------------------------------------
# 2. Cleaning + features
# --------------------------------------------------------------------------
HTML_COMMENT = re.compile(r"<!--.*?-->", re.S)
IMAGE_MD = re.compile(r"!\[[^\]]*\]\([^)]*\)")
CODE_FENCE = re.compile(r"```.*?```", re.S)
URL_RE = re.compile(r"https?://\S+")
STACK_RE = re.compile(r"^\s*at\s+\S.*:\d+(?::\d+)?\)?\s*$|Traceback \(most recent call last\)", re.M)
ERRCODE_RE = re.compile(r"\b(?:ECONN[A-Z]+|ENOTFOUND|ETIMEDOUT|ETIMEOUT|EPIPE|EADDRINUSE|EACCES|EPERM|ENOENT|EAI_AGAIN|EHOSTUNREACH|ENETUNREACH|ERR_[A-Z0-9_]+)\b")
HTTP_RE = re.compile(
    r"(?:status(?: code)?|http|response|error|code)\D{0,12}\b([45]\d\d)\b"
    r"|\b[45]\d\d\s+(?:unauthorized|forbidden|not found|bad request|internal server error|bad gateway|"
    r"service unavailable|gateway time-?out|payload too large|too many requests|method not allowed)", re.I)
VERSION_RE = re.compile(r"\b\d+\.\d+\.\d+\b|\bversion\b", re.I)
REPRO_RE = re.compile(r"steps? to reproduce|to reproduce|reproduc|codesandbox|stackblitz|jsfiddle|minimal (?:example|repro)|\brepro\b", re.I)

BAD_LABEL = re.compile(r"feature|enhancement|docs|documentation|dependenc|chore|proposal|\brfc\b|discussion", re.I)
BAD_TITLE = re.compile(r"^(?:feat|docs|chore|build|ci|test|refactor|release)\b[(:!]|^\[?(?:feature|rfc|proposal)\b|^bump\b|^update dependency|^v?\d+\.\d+(?:\.\d+)?\s*$", re.I)


def clean_body(b):
    b = (b or "").replace("\r\n", "\n")
    b = HTML_COMMENT.sub(" ", b)
    b = IMAGE_MD.sub(" ", b)
    b = re.sub(r"[ \t]+", " ", b)
    b = re.sub(r"\n{3,}", "\n\n", b).strip()
    return b


def norm_title(t):
    return re.sub(r"[^a-z0-9]+", " ", t.lower()).strip()


def ascii_ratio(s):
    return sum(ord(c) < 128 for c in s) / max(len(s), 1)


def first_phrase(text):
    low = text.lower()
    for ph in PHRASES:
        if ph.lower() in low:
            return ph
    return None


def snippet(body, n=150):
    """Short, template-free excerpt used when reviewing labels by eye."""
    s = CODE_FENCE.sub(" ", body)
    s = re.sub(r"^#+\s.*$", " ", s, flags=re.M)      # headings such as '### Describe the bug'
    s = re.sub(r"\*\*[^*]{1,40}\*\*:?", " ", s)       # '**Expected behaviour**'
    s = re.sub(r"\s+", " ", s).strip()
    return s[:n]


def build_pool():
    raw = json.load(open(P("raw_issues.json")))
    df = pd.DataFrame(raw)
    n0 = len(df)
    log = {"raw unique issues": n0}

    df = df[~df.is_pr]; log["after dropping PRs"] = len(df)
    df = df[(df.author_type != "Bot") & ~df.author_login.fillna("").str.endswith("[bot]")]; log["after dropping bots"] = len(df)
    df = df[df.state_reason == "completed"]; log["closed as completed"] = len(df)

    df["body_clean"] = df.body.map(clean_body)
    df = df[df.body_clean.str.len() >= 80]; log["body >= 80 chars"] = len(df)
    df = df[df.title.str.len() >= 8]
    df = df[~df.title.str.contains(BAD_TITLE)]
    df = df[~df.labels.map(lambda ls: any(BAD_LABEL.search(l) for l in ls))]; log["not feature/docs/chore"] = len(df)
    df = df[(df.title + " " + df.body_clean).map(ascii_ratio) >= 0.9]; log["english-ish"] = len(df)

    created = pd.to_datetime(df.created_at, utc=True)
    closed = pd.to_datetime(df.closed_at, utc=True)
    df["resolution_hours"] = (closed - created).dt.total_seconds() / 3600
    df = df[df.resolution_hours >= 0.01]

    # de-duplicate: same repo + same normalised title, then identical long titles across repos
    df["title_norm"] = df.title.map(norm_title)
    df = df.sort_values("created_at").drop_duplicates(["repo", "title_norm"], keep="first")
    long_title = df.title_norm.str.len() >= 25
    dup = df[long_title].duplicated("title_norm", keep="first")
    df = df.drop(dup[dup].index); log["after de-duplication"] = len(df)

    created = pd.to_datetime(df.created_at, utc=True)
    closed = pd.to_datetime(df.closed_at, utc=True)
    text_all = df.title + "\n" + df.body_clean
    no_code = df.body_clean.map(lambda b: CODE_FENCE.sub(" ", b))

    out = pd.DataFrame({
        "source": "GitHub",
        "url": df.html_url,
        "repository": df.repo,
        "issue_number": df.number,
        "report_title": df.title,
        "body": df.body_clean.str.slice(0, 3000),
        "matched_error_phrase": text_all.map(first_phrase),
        "reported_at_utc": created.dt.strftime("%Y-%m-%dT%H:%M:%S+00:00"),
        "resolved_at_utc": closed.dt.strftime("%Y-%m-%dT%H:%M:%S+00:00"),
        "resolution_hours": df.resolution_hours.round(4),
        "log_resolution_hours": df.resolution_hours.map(math.log1p).round(4),
        "closure_reason": df.state_reason,
        "title_len_words": df.title.str.split().map(len),
        "body_len_chars": df.body_clean.str.len(),
        "text_words_no_code": no_code.str.split().map(len),
        "n_code_blocks": df.body_clean.map(lambda b: len(CODE_FENCE.findall(b))),
        "n_urls": df.body_clean.map(lambda b: len(URL_RE.findall(b))),
        "has_stack_trace": df.body_clean.map(lambda b: int(bool(STACK_RE.search(b)))),
        "has_error_code": text_all.map(lambda t: int(bool(ERRCODE_RE.search(t)))),
        "has_http_status": text_all.map(lambda t: int(bool(HTTP_RE.search(t)))),
        "has_version_info": df.body_clean.map(lambda b: int(bool(VERSION_RE.search(b)))),
        "has_repro_steps": df.body_clean.map(lambda b: int(bool(REPRO_RE.search(b)))),
        "reported_year": created.dt.year,
        "author_association": df.author_association,
        "comment_count": df.comments,
        "reaction_count": df.reactions,
        "labels": df.labels.map(lambda ls: ";".join(ls)),
        "author_url": df.author_url,
        "endpoint_url": df.html_url,
        "query_hints": df.hints.map(lambda h: ";".join(h)),
    })
    out = out[out.text_words_no_code >= 8]
    log["enough prose (>= 8 words outside code)"] = len(out)

    props = [propose_label(t, b[:2000]) for t, b in zip(out.report_title, df.loc[out.index, "body_clean"])]
    out["candidate_Bug_Type"] = [p[0] for p in props]
    out["rule_confidence"] = [p[1] for p in props]
    out["rule_score"] = [p[2] for p in props]
    out["rule_margin"] = [p[3] for p in props]

    orig_urls = set()
    for base in (HERE, os.path.dirname(HERE)):
        orig_path = os.path.join(base, "devbugger_candidates.csv")
        if os.path.exists(orig_path):
            orig_urls = set(pd.read_csv(orig_path).url)
            break
    out["in_original_csv"] = out.url.isin(orig_urls)

    out = out.sort_values(["repository", "issue_number"]).reset_index(drop=True)
    out.to_csv(P("pool.csv"), index=False)
    for k, v in log.items():
        print(f"{k:<42}{v:>6}")
    print(f"{'pool.csv rows':<42}{len(out):>6}")
    print("\nrule label x confidence:")
    print(pd.crosstab(out.candidate_Bug_Type, out.rule_confidence).to_string())
    print("\ntop repos:")
    print(out.repository.value_counts().head(12).to_string())
    return out


# --------------------------------------------------------------------------
# 3. Review samples (the rows a human/Claude reads before they can enter the dataset)
# --------------------------------------------------------------------------
# Round 1 was a random sample of 80 per class (max 22 per repo) and is shipped frozen as
# review_round1.csv.  About 40% of it was rejected on reading (how-to questions, TypeScript
# typings, docs fixes, other front-end frameworks), so later rounds skip those up front.
SKIP_TITLE = re.compile(
    r"^(?:how|what|why|when|where|is it possible|is there|can i|can you|can we|could|should|does|question|\[question\]|help)\b"
    r"|\b(?:typescript|typings?|types?|d\.ts|jsdoc|docs?|documentation|readme|typo|deprecat\w+)\b"
    r"|\b(?:svelte|solid|vue|angular|nuxt)\b|\?\s*$", re.I)


SKIP_LABEL = re.compile(r"question|support|discussion|usage|documentation", re.I)


def reviewed_urls():
    urls = set()
    for f in glob.glob(P("review_round*.csv")):
        urls |= set(pd.read_csv(f).url)
    return urls


def make_review_sample(pool, round_no, per_class, per_repo=None, seed=42, exclude_repos=(), skip_junk=False, only_original=False):
    """Random mix of high + medium confidence proposals, capped per repo, never re-sampling reviewed rows."""
    per_repo = per_repo or {}
    done = reviewed_urls()
    if only_original:                      # every not-yet-reviewed row that came from the earlier candidates CSV
        sample = pool[pool.in_original_csv & ~pool.url.isin(done)].copy()
        sample.insert(0, "review_id", np.arange(1, len(sample) + 1) + round_no * 10000)
        sample.to_csv(P(f"review_round{round_no}.csv"), index=False)
        print(f"review_round{round_no}.csv rows: {len(sample)} (original-CSV rows)")
        print(sample.candidate_Bug_Type.value_counts().to_string())
        return sample
    chosen = []
    for c, want in per_class.items():
        cand = pool[(pool.candidate_Bug_Type == c) & pool.rule_confidence.isin(["high", "medium"])]
        cand = cand[~cand.url.isin(done) & ~cand.repository.isin(exclude_repos)]
        if skip_junk:
            cand = cand[~cand.report_title.str.contains(SKIP_TITLE)]
            if round_no >= 5:   # rounds 1-4 showed these are almost always rejected on reading
                cand = cand[~cand.body.str.contains("discussions-op-text", regex=False)
                            & ~cand.labels.fillna("").str.contains(SKIP_LABEL)
                            & (cand.text_words_no_code >= 20)]
        cand = cand.sample(frac=1, random_state=seed)
        cap, seen, n = per_repo.get(c, 22), {}, 0
        for r in cand.itertuples():
            if seen.get(r.repository, 0) >= cap:
                continue
            seen[r.repository] = seen.get(r.repository, 0) + 1
            chosen.append(r.url)
            n += 1
            if n >= want:
                break
    sample = pool[pool.url.isin(chosen)].copy()
    sample.insert(0, "review_id", np.arange(1, len(sample) + 1) + round_no * 10000)
    sample.to_csv(P(f"review_round{round_no}.csv"), index=False)
    print(f"review_round{round_no}.csv rows: {len(sample)}")
    print(sample.candidate_Bug_Type.value_counts().to_string())
    return sample


# --------------------------------------------------------------------------
# 4. Final assembly
# --------------------------------------------------------------------------
FINAL_COLUMNS = [
    "row_id", "source", "url", "repository", "issue_number", "report_title", "body", "matched_error_phrase",
    "reported_at_utc", "resolved_at_utc", "resolution_hours", "log_resolution_hours", "closure_reason",
    "title_len_words", "body_len_chars", "n_code_blocks", "n_urls", "has_stack_trace", "has_error_code",
    "has_http_status", "has_version_info", "has_repro_steps", "reported_year", "author_association",
    "comment_count", "reaction_count", "labels",
    "candidate_Bug_Type", "Bug_Type", "label_source", "review_status", "review_note", "review_round",
    "in_original_csv", "author_url", "content_license", "endpoint_url",
]


def _apply_cap(df, cap):
    """Shuffle, keep rows from your original CSV first, allow at most `cap` rows per (class, repo), shuffle again."""
    df = df.sample(frac=1, random_state=42)
    if cap:
        df = df.sort_values("in_original_csv", ascending=False, kind="stable")
        df = df.groupby(["Bug_Type", "repository"], group_keys=False).head(cap)
        df = df.sample(frac=1, random_state=43)
    return df.reset_index(drop=True)


def _pick_additions(extra, base, cap, add):
    """Per class: take one row per repo first, then a second per repo, ... (diversity first),
    never exceeding `cap` rows per (class, repo) once the base set is counted."""
    have = base.groupby(["Bug_Type", "repository"]).size()
    picked = []
    for c, n in add.items():
        x = extra[extra.Bug_Type == c].sample(frac=1, random_state=45)
        room = x.repository.map(lambda r: (cap or 10 ** 9) - int(have.get((c, r), 0)))
        x = x.assign(_k=x.groupby("repository").cumcount())
        x = x[x._k < room].sort_values("_k", kind="stable").head(n).drop(columns="_k")
        if len(x) < n:
            print(f"warning: only {len(x)} of the {n} requested rows exist for {c}")
        picked.append(x)
    return pd.concat(picked) if picked else extra.iloc[0:0]


def build_final(cap=None, base_rounds=0, add=None):
    files = sorted(glob.glob(P("review_round*.csv")))
    sample = pd.concat([pd.read_csv(f) for f in files], ignore_index=True).drop_duplicates("url")
    ov = pd.read_csv(P("label_overrides.csv"), dtype={"note": str}).fillna({"note": ""})
    ov_by_url = {r.url: (r.Bug_Type, r.note) for r in ov.itertuples()}
    unknown = set(ov.url) - set(sample.url)
    if unknown:
        sys.exit(f"overrides refer to rows that were never sampled: {sorted(unknown)[:5]}")

    rows = []
    for r in sample.itertuples():
        label, note, source = r.candidate_Bug_Type, "", "rule_confirmed_by_review"
        if r.url in ov_by_url:
            new, note = ov_by_url[r.url]
            if new == "DROP":
                continue
            if new not in CLASSES:
                sys.exit(f"bad label {new!r} for {r.url}")
            if new != label:
                source = "relabelled_in_review"
            label = new
        rows.append((r.url, label, source, note))
    lab = pd.DataFrame(rows, columns=["url", "Bug_Type", "label_source", "review_note"])
    df = sample.merge(lab, on="url")
    df["review_round"] = (df.review_id // 10000).clip(lower=1)     # round 1 ids are < 10000
    df["review_status"] = "claude_reviewed"        # change to 'verified' after YOUR spot-check
    df["content_license"] = np.nan

    if base_rounds:
        # Rounds <= base_rounds are the base set: same rows, same row_ids as when it was first delivered.
        base = _apply_cap(df[df.review_round <= base_rounds].reset_index(drop=True), cap)
        base.insert(0, "row_id", np.arange(1, len(base) + 1))
        extra = df[(df.review_round > base_rounds) & ~df.url.isin(base.url)]
        extra = _pick_additions(extra, base, cap, add or {}).sample(frac=1, random_state=46).reset_index(drop=True)
        extra.insert(0, "row_id", np.arange(len(base) + 1, len(base) + len(extra) + 1))
        df = pd.concat([base, extra]).sample(frac=1, random_state=44).reset_index(drop=True)   # file order is shuffled
    else:
        df = _apply_cap(df, cap)                                      # shuffled, so head()/tail() splits are safe
        df.insert(0, "row_id", np.arange(1, len(df) + 1))
    df = df[FINAL_COLUMNS]
    df.to_csv(P("devbugger_dataset.csv"), index=False)
    print(f"devbugger_dataset.csv rows: {len(df)}")
    print(df.Bug_Type.value_counts().to_string())
    return df


# --------------------------------------------------------------------------
# 5. Audit: how trustworthy / how leaky is the dataset?   (python build_dataset.py audit)
# --------------------------------------------------------------------------
# Library / brand names.  Masking them shows how much a classifier relies on *which library is
# mentioned* instead of *what went wrong*.  Concept words (cors, jwt, mongodb) are NOT masked.
LIB_NAMES = [
    "mongoose", "jsonwebtoken", "passport(?:-jwt|-local)?", "express(?:-jwt|-session)?", "axios", "socket\\.?io", "engine\\.io",
    "redux(?:-toolkit|-thunk|-persist)?", "react-redux", "rtk", "zustand", "jotai", "mobx(?:-react(?:-lite)?)?", "react-query",
    "tanstack", "apollo", "strapi", "meteor", "rocket\\.?chat", "parse(?: server)?", "payload", "next-?auth", "next\\.?js", "multer",
    "body-?parser", "node-fetch", "webpack(?:-dev-server)?", "vite", "bcrypt(?:js)?", "jwks-rsa", "agenda", "got",
]
LIB_RE = re.compile(r"\b(?:" + "|".join(LIB_NAMES) + r")\b", re.I)


def audit():
    import warnings
    warnings.filterwarnings("ignore")
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression, Ridge
    from sklearn.metrics import accuracy_score, f1_score, r2_score
    from sklearn.metrics.pairwise import cosine_similarity
    from sklearn.model_selection import KFold, StratifiedKFold, cross_val_predict
    from sklearn.pipeline import make_pipeline

    df = pd.read_csv(P("devbugger_dataset.csv"))
    y = df.Bug_Type
    text = df.report_title + " " + df.body.fillna("")
    print(f"rows {len(df)} | repos {df.repository.nunique()} | classes\n{y.value_counts().to_string()}")
    vc = df.repository.value_counts()
    print(f"\ntop-1 repo share {vc.iloc[0] / len(df):.0%} | top-3 repo share {vc.iloc[:3].sum() / len(df):.0%}")
    print("largest single-repo share inside each class:")
    print(df.groupby("Bug_Type").repository.agg(lambda s: s.value_counts(normalize=True).iloc[0]).map("{:.0%}".format).to_string())

    X = TfidfVectorizer(stop_words="english").fit_transform(text.str.lower())
    S = cosine_similarity(X)
    np.fill_diagonal(S, 0)
    print(f"\nnear-duplicate pairs (cosine >= 0.80): {int((np.triu(S) >= 0.80).sum())}")

    cv = StratifiedKFold(5, shuffle=True, random_state=0)
    print(f"\n--- classification, 5-fold CV (a sanity check, not a result for your report) ---")
    print(f"majority-class baseline          acc {y.value_counts(normalize=True).iloc[0]:.2f}")
    pred = pd.Series(index=df.index, dtype=object)
    for tr, te in cv.split(df, y):
        maj = df.iloc[tr].groupby("repository").Bug_Type.agg(lambda s: s.value_counts().index[0])
        pred.iloc[te] = df.iloc[te].repository.map(maj).fillna(y.iloc[tr].value_counts().index[0]).values
    print(f"repository name ONLY             acc {accuracy_score(y, pred):.2f} | macro-F1 {f1_score(y, pred, average='macro'):.2f}")
    def run(name, t):
        m = make_pipeline(TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True, stop_words="english"), LogisticRegression(max_iter=2000, C=5))
        p = cross_val_predict(m, t, y, cv=cv)
        print(f"{name:<32} acc {accuracy_score(y, p):.2f} | macro-F1 {f1_score(y, p, average='macro'):.2f}")
    run("TF-IDF+LogReg, title", df.report_title)
    run("TF-IDF+LogReg, title+body", text)
    run("  same, library names masked", text.map(lambda t: LIB_RE.sub(" LIB ", t)))

    print(f"\n--- regression target log1p(resolution_hours), 5-fold CV R^2 ---")
    t = df.log_resolution_hours
    kf = KFold(5, shuffle=True, random_state=0)
    for name, key in [("class mean", "Bug_Type"), ("repository mean", "repository")]:
        p = pd.Series(index=df.index, dtype=float)
        for tr, te in kf.split(df):
            mu = t.iloc[tr].groupby(df[key].iloc[tr]).mean()
            p.iloc[te] = df[key].iloc[te].map(mu).fillna(t.iloc[tr].mean()).values
        print(f"{name:<32} R^2 {r2_score(t, p):.2f}")
    m = make_pipeline(TfidfVectorizer(min_df=2, sublinear_tf=True, stop_words="english"), Ridge(alpha=3))
    print(f"{'TF-IDF + Ridge (text only)':<32} R^2 {r2_score(t, cross_val_predict(m, text, t, cv=kf)):.2f}")


def parse_kv(s, cast=int):
    return {k: cast(v) for k, v in (kv.split("=") for kv in s.split(",") if kv)}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("step", choices=["pool", "sample", "final", "audit"])
    ap.add_argument("--round", type=int, default=2)
    ap.add_argument("--counts", default="", help="rows to sample per class, e.g. Database_Connection=70,Authentication=25")
    ap.add_argument("--per-repo", default="", help="repo cap per class, e.g. Database_Connection=35 (default 22)")
    ap.add_argument("--skip-repos", default="", help="comma-separated repos to leave out")
    ap.add_argument("--cap", type=int, default=0, help="final: max rows per (class, repo); keeps original-CSV rows first")
    ap.add_argument("--base-rounds", type=int, default=0, help="final: rounds up to N are the base set (rows and row_ids stay as first delivered)")
    ap.add_argument("--add", default="", help="final: rows to add per class from later rounds, e.g. CORS_Error=35,API_Error=35")
    ap.add_argument("--original", action="store_true", help="sample every unreviewed row that came from your earlier candidates CSV")
    a = ap.parse_args()
    if a.step == "pool":
        build_pool()
    elif a.step == "sample":
        pool = pd.read_csv(P("pool.csv"))
        make_review_sample(pool, a.round, parse_kv(a.counts), parse_kv(a.per_repo),
                           exclude_repos=[r for r in a.skip_repos.split(",") if r], skip_junk=a.round >= 2 and not a.original,
                           only_original=a.original)
    elif a.step == "audit":
        audit()
    else:
        build_final(a.cap or None, a.base_rounds, parse_kv(a.add))
